package com.lastica.movies

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF090B0D)
private val Panel = Color(0xFF171B1E)
private val Cyan = Color(0xFF22D3D8)
private val Muted = Color(0xFF9AA3A8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(background = Ink, surface = Panel, primary = Cyan)) { LasticaApp() } }
    }
}

@Composable
fun LasticaApp() {
    var tab by remember { mutableStateOf("Home") }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<String?>(null) }
    val movies = listOf("Runner", "The Last Mission", "Shadow City", "Beyond Earth", "Night Chase", "Final Signal")
    val shown = movies.filter { it.contains(query, true) }
    Scaffold(containerColor = Ink, bottomBar = {
        NavigationBar(containerColor = Color(0xFF101315), contentColor = Color.White) {
            listOf("Home", "Explore", "Watchlist", "Profile").forEach { item ->
                val icon = when(item) { "Home" -> Icons.Default.Home; "Explore" -> Icons.Default.Search; "Watchlist" -> Icons.Default.Bookmark; else -> Icons.Default.Person }
                NavigationBarItem(selected = tab == item, onClick = { tab = item; selected = null }, icon = { Icon(icon, null) }, label = { Text(item) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Cyan, selectedTextColor = Cyan, indicatorColor = Color(0xFF203236), unselectedIconColor = Muted, unselectedTextColor = Muted))
            }
        }
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).background(Ink).padding(horizontal = 18.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text("LASTICA", color = Cyan, fontSize = 23.sp, fontWeight = FontWeight.Black); Text(" MOVIES", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
                Icon(Icons.Default.NotificationsNone, "Notifications", tint = Color.White, modifier = Modifier.size(25.dp))
            }
            if (tab == "Explore") {
                OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search movies", color = Muted) }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Panel, focusedTextColor = Color.White, unfocusedTextColor = Color.White))
            }
            if (selected != null) {
                Text("‹  Back", color = Cyan, modifier = Modifier.clickable { selected = null }.padding(vertical = 10.dp))
                Hero(selected!!, true)
                Text("${selected!!}", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
                Text("Action • Thriller • 2026", color = Muted, modifier = Modifier.padding(top = 6.dp))
                Text("A race against time begins when an unexpected mission changes everything.", color = Color.LightGray, modifier = Modifier.padding(top = 12.dp))
                Button(onClick = { }, colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Ink), modifier = Modifier.padding(top = 16.dp)) { Icon(Icons.Default.PlayArrow, null); Text("  Play trailer") }
            } else if (tab == "Profile") {
                Spacer(Modifier.height(32.dp)); Icon(Icons.Default.AccountCircle, null, tint = Cyan, modifier = Modifier.size(72.dp).align(Alignment.CenterHorizontally)); Text("Your profile", color = Color.White, fontSize = 24.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(12.dp)); Text("Sign-in and account features can be connected in the next version.", color = Muted)
            } else {
                if (tab == "Home") {
                    Hero("Runner", false)
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 12.dp, bottom = 8.dp)) { Text("★  8.3/10", color = Color(0xFFFFC84A), fontWeight = FontWeight.Bold); Text("   •   2026   •   1h 37m", color = Muted) }
                    Text("A former soldier is thrown into a brutal race against time when a critical delivery makes him a target.", color = Color.White, fontSize = 15.sp, lineHeight = 22.sp)
                    Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { selected = "Runner" }, colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Ink)) { Icon(Icons.Default.PlayArrow, null); Text(" Play") }
                        OutlinedButton(onClick = { tab = "Watchlist" }) { Icon(Icons.Default.BookmarkAdd, null); Text(" Save") }
                    }
                }
                Text(if(tab == "Watchlist") "Your Watchlist" else if(tab == "Explore") "Explore Movies" else "Trending Movies Today", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 22.dp, bottom = 12.dp))
                val list = if(tab == "Watchlist") emptyList() else shown
                if(tab == "Watchlist") Text("Your saved movies will appear here.", color = Muted)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    list.forEachIndexed { index, name -> MovieTile(name, index, onClick = { selected = name }) }
                }
            }
        }
    }
}

@Composable
fun Hero(title: String, compact: Boolean) {
    Box(Modifier.fillMaxWidth().height(if(compact) 220.dp else 270.dp).clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0xFF174A50), Color(0xFF17242B), Color(0xFF5B3327))))) {
        Column(Modifier.align(Alignment.BottomStart).padding(18.dp)) {
            Text("EXCLUSIVE PREMIERE", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text(title.uppercase(), color = Color.White, fontSize = if(compact) 32.sp else 38.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            Text("ACTION  •  THRILLER", color = Color.LightGray, fontSize = 11.sp)
        }
        Text("✦", color = Color.White.copy(alpha = .16f), fontSize = 100.sp, modifier = Modifier.align(Alignment.TopEnd).padding(18.dp))
    }
}

@Composable
fun MovieTile(title: String, index: Int, onClick: () -> Unit) {
    val shades = listOf(Color(0xFF25434C), Color(0xFF563B32), Color(0xFF333A58), Color(0xFF405047), Color(0xFF58434D), Color(0xFF344D58))
    Column(Modifier.width(132.dp).clickable(onClick = onClick)) {
        Box(Modifier.fillMaxWidth().height(174.dp).clip(RoundedCornerShape(14.dp)).background(Brush.verticalGradient(listOf(shades[index % shades.size], Color(0xFF121619)))), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.LocalMovies, null, tint = Color.White.copy(alpha = .45f), modifier = Modifier.size(42.dp))
            Text("2026", color = Color.White.copy(alpha = .75f), fontSize = 10.sp, modifier = Modifier.align(Alignment.BottomStart).padding(9.dp))
        }
        Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 7.dp), maxLines = 1)
        Text("Action • HD", color = Muted, fontSize = 11.sp)
    }
}
